from django.apps import AppConfig


class InvestmentConfig(AppConfig):
    name = 'investment'
