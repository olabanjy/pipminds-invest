# from django import forms
# from .models import *



# class ProcessInvestmentForm(forms.Form):
#     display_name = forms.Charfield(required=True, widget=forms.TextInput())
#     iv-amount = forms.IntegerField(required=True, widget=forms.NumberInput())

#     destination = forms.ChoiceField(required=False, choices=DESTINATION, widget=forms.Select(attrs={
#         'class':'form-control form-control-lg',
#         'id': 'destination'
#     }))