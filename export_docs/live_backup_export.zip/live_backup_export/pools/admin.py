from django.contrib import admin
from .models import * 

# Register your models here.


admin.site.register(PoolPeriod)
admin.site.register(PoolOfferings)
admin.site.register(PoolType)
admin.site.register(PoolInstance)
admin.site.register(UserPoolSlots)
admin.site.register(PoolsWallet)
admin.site.register(UserOfferingsPurchase)
